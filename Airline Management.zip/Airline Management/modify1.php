<?php 
require_once "config.php";
if(isset($_POST['submit']))
{
	$count=0;
	$catch=$_POST['id'];
	$sql="select * from flights where id='$catch'";
	$res=mysqli_query($con,$sql);
	if(mysqli_num_rows($res)>0)
	{
		while($row=mysqli_fetch_assoc($res))
		{
			if($catch==$row['id'])
			{
				$id = $_POST['id'];
                $name = $_POST['name'];
                $source = $_POST['source'];
                $destination = $_POST['destination'];
                $departure = $_POST['departure'];
                $arrival = $_POST['arrival'];
                $fair_economic = $_POST['fair_economic'];
                $fair_business = $_POST['fair_business'];
                $available_seats = $_POST['available_seats'];

				$count+=1;
			}
			else
			{
				$count=0;
			}
		}
	}
	if($count==0)
	{
		echo "<script>alert('Flight Code not in database')</script>";
		echo "<script>window.location='modifyflight.html'</script>";
	}
	$sql="insert into selected(FLIGHT_CODE) values('$catch')";
	$res=mysqli_query($con,$sql);
}
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style>
		*{
			margin: 0;
			padding: 0;
			font-family: Century Gothic;
		}
		ul{
			float: right;
			list-style-type: none;
			margin-top: 25px;
		}
		ul li{
			display: inline-block;
		}
		ul li a{
			text-decoration: none;
			color: #fff;
			padding: 5px 20px;
			border: 1px solid #fff;
			transition: 0.6s ease;
		}
		ul li a:hover{
			background-color: #fff;
			color: #000;
		}
		ul li.active a{
			background-color: #fff;
			color: #000;
		}
		.title{
			position: absolute;
			top: 20%;
			left: 50%;
			transform: translate(-50%,-50%);	
		}
		.title h1{
			color: #fff;
			font-size: 70px;
		}
		body{
			background-image:linear-gradient(rgba(0,0,0,0.5),rgba(0,0,0,0.5)), url(plane.jpg);
			height: 100vh;
			background-size: cover;
			background-position: center;
		}
		table.a{
			position: absolute;
			top: 60%;
			left: 50%;
			transform: translate(-50%,-50%);
			border: 1px solid #fff;
			padding: 10px 30px;
			color: #fff;
			text-decoration: none;
			transition: 0.6s ease;
			font-size: 25px;
		}
		input[type=submit]{
			border: 1px solid #fff;
			padding: 10px 30px;
			text-decoration: none;
			transition: 0.6s ease;
		}
		input[type=submit]:hover{
			background-color: #fff;
			color: #000;
		}
		input[type=text], select {
		  width: 100%;
		  padding: 12px 20px;
		  margin: 8px 0;
		  display: inline-block;
		  border: 1px solid #ccc;
		  border-radius: 4px;
		  box-sizing: border-box;
		}
		input[type=number], select {
		  width: 100%;
		  padding: 12px 20px;
		  margin: 8px 0;
		  display: inline-block;
		  border: 1px solid #ccc;
		  border-radius: 4px;
		  box-sizing: border-box;
		}
		input[type=date], select {
		  width: 100%;
		  padding: 12px 20px;
		  margin: 8px 0;
		  display: inline-block;
		  border: 1px solid #ccc;
		  border-radius: 4px;
		  box-sizing: border-box;
		}	
	</style>
</head>
<body>
	<div class="main">
			<ul>
				<li class="active"><a href="#">Modify Flight Details</a></li> 
			</ul>
	</div>
	<div class="title">
		<h1>Modify Flight Details</h1>
	</div>
	<form action="modify2.php" method="post">
		<table class='a' cellspacing="30">
			<tr>
				<td>Name</td>
				<td><input type="text" placeholder=<?php echo $name ?> name="name"></td>
				<td>Source</td>
				<td><input type="text" placeholder=<?php echo $arrival ?> name="source"></td>
				<td>Destination</td>
				<td><input type="text" placeholder=<?php echo $duration ?> name="destination"></td>
                <td>Departure</td>
				<td><input type="text" placeholder=<?php echo $duration ?> name="departure"></td>
                <td>Arrival</td>
				<td><input type="text" placeholder=<?php echo $duration ?> name="arrival"></td>
                <td>Fair_Economic</td>
				<td><input type="text" placeholder=<?php echo $duration ?> name="fair_economic"></td>
                <td>Fair_Business</td>
				<td><input type="text" placeholder=<?php echo $duration ?> name="fair_business"></td>
                <td>Available_seats</td>
				<td><input type="text" placeholder=<?php echo $duration ?> name="available_seats"></td>
			</tr>
			
		</table>
</body>
</html>