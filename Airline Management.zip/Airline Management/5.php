<?php
session_start();

// Include database connection
include 'config.php';

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Query to fetch password from the database for the given username
    $sql = "SELECT Password FROM userlogin WHERE Username = '$username'";
    $result = mysqli_query($conn, $sql);

    // Check if a matching username is found in the database
    if (mysqli_num_rows($result) == 1) {
        $row = mysqli_fetch_assoc($result);
        $db_password = $row['Password'];

        // Verify if the entered password matches the password from the database
        if ($password === $db_password) {
            // Authentication successful
            $_SESSION['user'] = true; // Set session variable
            header("Location: Customeroption.html"); // Redirect to customer option page
            exit();
        } else {
            // Authentication failed
            echo "Invalid username or password!";
        }
    } else {
        // Username not found
        echo "Invalid username or password!";
    }

    // Close database connection
    mysqli_close($conn);
}
?>
