<?php
// Include database connection file
include 'config.php';

// Fetch flight details from the database
$sql = "SELECT * FROM flights";
$result = mysqli_query($conn, $sql);
?>

<!DOCTYPE html>
<html>
<head>
    <title>View Flights</title>
    <style>
        table {
            width: 100%;
            border-collapse: collapse;
        }

        table, th, td {
            border: 1px solid black;
            padding: 8px;
            text-align: left;
        }

        th {
            background-color: #f2f2f2;
        }
    </style>
</head>
<body>

<h2>Flight Details</h2>

<table>
    <tr>
        <th>Flight ID</th>
        <th>Plane Name</th>
        <th>Source</th>
        <th>Destination</th>
        <th>Departure Time</th>
        <th>Arrival Time</th>
        <th>Economic Fare</th>
        <th>Business Fare</th>
        <th>Available Seats</th>
    </tr>
    <?php
    // Loop through each row of the result set
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>";
        echo "<td>" . $row['Id'] . "</td>";
        echo "<td>" . $row['Name'] . "</td>";
        echo "<td>" . $row['Source'] . "</td>";
        echo "<td>" . $row['Destination'] . "</td>";
        echo "<td>" . $row['Departure'] . "</td>";
        echo "<td>" . $row['Arrival'] . "</td>";
        echo "<td>" . $row['Fair_Economic'] . "</td>";
        echo "<td>" . $row['Fair_Business'] . "</td>";
        echo "<td>" . $row['Available_seats'] . "</td>";
        echo "</tr>";
    }
    ?>
</table>

</body>
</html>
