<?php
include 'config.php';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['submit'])) {
    $id = $_POST['UserId'];

    $test = "SELECT * FROM users WHERE UserId = $id";
    $result = mysqli_query($conn, $test);
    $row = mysqli_fetch_array($result, MYSQLI_ASSOC);

    $count = mysqli_num_rows($result);

    if ($count == 0) {
        $error = "User ID NOT FOUND!!!<br><br>";
        echo $error;
        header("Refresh:2; url=cancelbook.html");
    } else {
        $temp = $row['Flight_Id'];
        $sql = "DELETE FROM users WHERE UserId = $id";

        if (!mysqli_query($conn, $sql)) {
            echo "Not Canceled!!!";
        } else {
            $sql1 = "SELECT * FROM flights WHERE Id = $temp";
            $result1 = mysqli_query($conn, $sql1);
            $row2 = mysqli_fetch_array($result1, MYSQLI_ASSOC);
            $updated_seats = $row2['Available_seats'] + $row['Seats_booked'];

            $sql2 = "UPDATE flights SET Available_seats = '$updated_seats' WHERE Id = $temp";
            mysqli_query($conn, $sql2);

            echo "Flight Canceled Successfully!!!";
        }

        header("Refresh:2; url=Customeroption.html");
    }
}

mysqli_close($conn);
?>
