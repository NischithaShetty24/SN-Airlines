<?php
include 'config.php';

// Check if the form data is received
if(isset($_POST['id']) && isset($_POST['name']) && isset($_POST['source']) && isset($_POST['destination']) && isset($_POST['departure']) && isset($_POST['arrival']) && isset($_POST['Fair_Economic']) && isset($_POST['Fair_Business'])) {
    // Retrieve form data
    $id = $_POST['id'];
    $name = $_POST['name'];
    $source = $_POST['source'];
    $destination = $_POST['destination'];
    $departure = $_POST['departure'];
    $arrival = $_POST['arrival'];
    $fair_economic = $_POST['Fair_Economic'];
    $fair_business = $_POST['Fair_Business'];

    // Update the flight details in the database
    $sql = "UPDATE flights SET Name='$name', Source='$source', Destination='$destination', Departure='$departure', Arrival='$arrival', Fair_Economic='$fair_economic', Fair_Business='$fair_business' WHERE Id = $id";

    if(mysqli_query($conn, $sql)) {
        echo "Flight Updated Successfully!!!";
    } else {
        echo "Error: " . mysqli_error($conn);
    }
} else {
    echo "Error: Form data not received.";
}

// Redirect to m1.html after 2 seconds
header("Refresh:2; url=modifyflight.html");

// Close the database connection
mysqli_close($conn);
?>
