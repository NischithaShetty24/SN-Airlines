<?php
include 'config.php';

$flight_id = $_POST['id'];
$firstname = $_POST['name'];
$lastname = $_POST['lastname'];
$mobileno = $_POST['mobileNumber'];
$email = $_POST['email'];
$class = $_POST['Class']; // Corrected Class to match with the select name
$seats_booked = $_POST['seatsBooked'];

// Generate a random UserId
$userid = rand(100, 999);

// Inserting data into the users table
$sql = "INSERT INTO users (UserId, Flight_Id, FirstName, LastName, MobileNo, Email, `Class`, Seats_booked)  VALUES ('$userid', '$flight_id', '$firstname', '$lastname', '$mobileno', '$email', '$class', '$seats_booked')";
$result = mysqli_query($conn, $sql);

// Updating available seats in flights table
$sql = "SELECT Available_seats FROM flights WHERE Id = $flight_id";
$result = mysqli_query($conn, $sql);
$row = mysqli_fetch_assoc($result);
$updated_seats = $row['Available_seats'] - $seats_booked;

$sql = "UPDATE flights SET Available_seats = $updated_seats WHERE Id = $flight_id";
$result = mysqli_query($conn, $sql);

mysqli_close($conn);
?>

<!DOCTYPE html>
<html>
<head>
<meta http-equiv="refresh" content="2;url=payment.html">
<style>
body {
  background-image: url("plane.jpg");
  background-repeat: no-repeat;
  background-size: cover;
  text-align: center;
  padding-top: 50px;
}
</style>
</head>
<body>

<p>Passenger Details Entered Successfully!</p>
<p><strong>Ticket ID:</strong> <?php echo $userid; ?></p>
<p>Redirecting to payment page...</p>

</body>
</html>
