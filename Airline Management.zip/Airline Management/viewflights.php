<?php
// Include database connection file
include 'config.php';

// Fetch flight details from the database
$sql = "SELECT * FROM flights";
$result = mysqli_query($conn, $sql);
?>
<!DOCTYPE html>
<html>
<head>
	<title></title>
	<style>
		*{
			margin: 0;
			padding: 0;
			font-family: Century Gothic;
		}
		ul{
			float: right;
			list-style-type: none;
			margin-top: 25px;
		}
		ul li{
			display: inline-block;
		}
		ul li a{
			text-decoration: none;
			color: #fff;
			padding: 5px 20px;
			border: 1px solid #fff;
			transition: 0.6s ease;
		}
		ul li a:hover{
			background-color: #fff;
			color: #000;
		}
		ul li.active a{
			background-color: #fff;
			color: #000;
		}
		.title{
			position: absolute;
			top: 15%;
			left: 40%;
			/*transform: translate(-50%,-50%);*/	
		}
		.title h1{
			color: #fff;
			font-size: 70px;
		}
		body{
			background-image:linear-gradient(rgba(0,0,0,0.5),rgba(0,0,0,0.5)), url(plane.jpg);
			height: 100vh;
			background-size: cover;
			background-position: center;
		}
		table.a{
			position: absolute;
			top: 27%;
			left: 0%;
			/*transform: translate(-50%,-50%);*/
			border: 1px solid #fff;
			padding: 10px 30px;
			color: #fff;
			text-decoration: none;
			transition: 0.6s ease;
			font-size: 18px;
		}
		button[type="submit"]{
			border: 1px solid #fff;
			padding: 10px 30px;
			text-decoration: none;
			transition: 0.6s ease;
		}
		button[type="submit"]:hover{
			background-color: #fff;
			color: #000;
		}
	</style>
</head>
<body>
	<div class="main">
			<ul>
				<li class="active"><a href="#">All Flights</a></li>
				<li><a href="adminoption.html">Admin</a></li>
				<li><a href="ab.html">Home</a></li>
			</ul>
		</div>
	<div class="title">
		<h1>All Flights</h1>
	</div>
	<table class="a">
	<table>
    <tr>
        <th>Flight ID</th>
        <th>Plane Name</th>
        <th>Source</th>
        <th>Destination</th>
        <th>Departure Time</th>
        <th>Arrival Time</th>
        <th>Economic Fare</th>
        <th>Business Fare</th>
        <th>Available Seats</th>
    </tr>
    <?php
    // Loop through each row of the result set
    while ($row = mysqli_fetch_assoc($result)) {
        echo "<tr>";
        echo "<td>" . $row['Id'] . "</td>";
        echo "<td>" . $row['Name'] . "</td>";
        echo "<td>" . $row['Source'] . "</td>";
        echo "<td>" . $row['Destination'] . "</td>";
        echo "<td>" . $row['Departure'] . "</td>";
        echo "<td>" . $row['Arrival'] . "</td>";
        echo "<td>" . $row['Fair_Economic'] . "</td>";
        echo "<td>" . $row['Fair_Business'] . "</td>";
        echo "<td>" . $row['Available_seats'] . "</td>";
        echo "</tr>";
    }
    ?>
</table>
	</form>
	</table>
</body>
</html>