<!DOCTYPE html>
<html>
<head>
    <title>Available Flights</title>
    <style>
        body {
            background-image: url('plane.jpg'); /* Replace 'background_image.jpg' with the path to your background image */
            background-size: cover;
            font-family: Century Gothic;
            color: black; /* Changed text color to black */
        }

        .container {
            text-align: center;
            margin-top: 50px;
        }

        h1 {
            font-size: 40px;
            font-weight: bold;
            font-family: 'Arial Black', sans-serif; /* Changed font family */
            color: black; /* Changed heading color to black */
        }

        table {
            margin: auto;
            border-collapse: collapse;
            width: 80%;
            margin-top: 20px;
        }

        th, td {
            padding: 10px;
            text-align: center;
            border: 1px solid black; /* Changed border color to black */
        }

        th {
            font-size: 20px;
        }

        td {
            font-size: 18px;
        }

        td a {
            color: blue;
            text-decoration: none;
        }

        td a:hover {
            color: lightblue;
        }

        .book-button {
            background-color: blue;
            color: white;
            padding: 5px 10px;
            border: none;
            border-radius: 5px;
            text-decoration: none;
        }

        .book-button:hover {
            background-color: lightblue;
        }
    </style>
</head>
<body>
    <div class="container">
        <h1>Available Flights</h1>
        <?php
            // Step 1: Connect to the database
            $servername = "localhost";
            $username = "root";
            $password = "";
            $dbname = "new";

            $conn = new mysqli($servername, $username, $password, $dbname);

            // Check connection
            if ($conn->connect_error) {
                die("Connection failed: " . $conn->connect_error);
            }

            // Step 2: Retrieve available flights based on source, destination, and date
            if(isset($_POST['search'])) {
                $source = $_POST['source'];
                $destination = $_POST['destination'];
                $date = $_POST['departure'];

                $sql = "SELECT * FROM flights WHERE Source='$source' AND Destination='$destination' AND Departure='$date'";
                $result = $conn->query($sql);

                if ($result->num_rows > 0) {
                    // Step 3: Display available flights in a table format
                    echo "<table border='1'>
                    <tr>
                    <th>Flight Id</th>
                    <th>Flight Name</th>
                    <th>Source</th>
                    <th>Destination</th>
                    <th>Departure</th>
                    <th>Arrival</th>
                    <th>Economic Fair</th>
                    <th>Business Fair</th>
                    <th>Available Seats</th>
                    <th>Action</th>
                    </tr>";
                    while($row = $result->fetch_assoc()) {
                        echo "<tr>";
                        echo "<td>" . $row['Id'] . "</td>";
                        echo "<td>" . $row['Name'] . "</td>";
                        echo "<td>" . $row['Source'] . "</td>";
                        echo "<td>" . $row['Destination'] . "</td>";
                        echo "<td>" . $row['Departure'] . "</td>";
                        echo "<td>" . $row['Arrival'] . "</td>";
                        echo "<td>" . $row['Fair_Economic'] . "</td>";
                        echo "<td>" . $row['Fair_Business'] . "</td>";
                        echo "<td>" . $row['Available_seats'] . "</td>";
                        // Step 4: Provide a button to allow customers to book a particular flight
                        echo "<td><a class='book-button' href='passengerdetails.html?flight_id=" . $row['Id'] . "'>Book</a></td>";
                        echo "</tr>";
                    }
                    echo "</table>";
                } else {
                    echo "No flights available for the selected criteria";
                }
            }

            $conn->close();
        ?>
    </div>
</body>
</html>
