<?php
session_start();
include 'config.php';

// Retrieve user ID from session
$userId = $_SESSION['userId'] ?? null;

if ($userId) {
    // Query to retrieve ticket information based on user ID
    $sql = "SELECT u.FirstName, u.MobileNo, f.Source, f.Destination, f.Departure, f.Id as Flight_Id, u.Seats_booked
            FROM users u
            INNER JOIN flights f ON u.Flight_Id = f.Id
            WHERE u.UserId = $userId";
    
    // Execute the query
    $result = mysqli_query($conn, $sql);

    // Check if any tickets found
    if (mysqli_num_rows($result) > 0) {
        // Start HTML output
        echo "<!DOCTYPE html>";
        echo "<html lang='en'>";
        echo "<head>";
        echo "<meta charset='UTF-8'>";
        echo "<meta name='viewport' content='width=device-width, initial-scale=1.0'>";
        echo "<title>View Ticket</title>";
        echo "<style>";
        echo "body {";
        echo "    font-family: 'Segoe Script', sans-serif;";
        echo "    background-color: #f0f0f0;";
        echo "    margin: 0;";
        echo "}";
        echo ".container {";
        echo "    width: 70%;";
        echo "    margin: 20px auto;"; // Reduced margin
        echo "    padding: 30px;";
        echo "    border-radius: 15px;";
        echo "    position: relative;"; // Added position relative
        echo "}";
        echo ".logo {";
        echo "    float: left;";
        echo "    margin-right: 20px;";
        echo "}";
        echo ".logo img {";
        echo "    max-width: 100px;";
        echo "}";
        echo ".sn-airline {";
        echo "    font-size: 32px;";
        echo "    font-weight: bold;";
        echo "    margin-top: 20px;";
        echo "}";
        echo ".e-ticket {";
        echo "    text-align: center;";
        echo "    font-size: 36px;";
        echo "    margin-bottom: 15px;";
        echo "}";
        echo ".ticket-info {";
        echo "    margin-top: 10px;";
        echo "    padding: 20px;";
        echo "    background-color: #ffffff;";
        echo "    border-radius: 10px;";
        echo "}";
        echo ".ticket-info p {";
        echo "    font-size: 18px;";
        echo "    margin-bottom: 10px;";
        echo "}";
        echo ".passenger-info {";
        echo "    margin-top: 10px;";
        echo "    padding: 20px;";
        echo "    background-color: #ffffff;";
        echo "    border-radius: 10px;";
        echo "}";
        echo ".passenger-info p {";
        echo "    font-size: 20px;";
        echo "    margin-bottom: 10px;";
        echo "}";
        echo ".happy-journey {";
        echo "    font-size: 28px;";
        echo "    font-weight: bold;";
        echo "    position: absolute;";
        echo "    top: 0;";
        echo "    right: 0;";
        echo "    margin: 20px;";
        echo "}";
        echo ".passenger-img {";
        echo "    position: absolute;";
        echo "    top: 40px;"; // Adjusted position
        echo "    right: 20px;";
        echo "}";
        echo "</style>";
        echo "</head>";
        echo "<body>";

        // Happy journey text
        echo "<div class='happy-journey'>HAPPY JOURNEY</div>";

        // Airline logo and heading
        echo "<div class='logo'>";
        echo "<img src='pl.png' alt='SN Airline'>";
        echo "</div>";
        echo "<div class='sn-airline'>SN Airline</div>";
        echo "<h1 class='e-ticket'>E Ticket</h1>";

        // Ticket information box
        echo "<div class='container'>";
        echo "<div class='ticket-info'>";
        
        // Output data of each row
        while ($row = mysqli_fetch_assoc($result)) {
            echo "<p><b>Source:</b> " . $row["Source"] . " &nbsp;&nbsp;&nbsp;➔&nbsp;&nbsp;&nbsp; <b>Destination:</b> " . $row["Destination"] . "</p>";
            echo "<p><b>Departure:</b> " . $row["Departure"] . "&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Flight ID:</b> " . $row["Flight_Id"] . "</p>";
        }

        // Close ticket information box
        echo "</div>";
        echo "</div>"; // This closes the container

        // Passenger information
        echo "<h2 class='e-ticket' style='text-align:center;'>Passenger Information</h2>";
        echo "<div class='container'>";
        echo "<div class='passenger-info'>";
        
        // Reset mysqli_data_seek to retrieve the data again
        mysqli_data_seek($result, 0);
        
        // Output data of each row
        $row = mysqli_fetch_assoc($result);
        echo "<p><b>First Name:</b> " . $row["FirstName"] . "</p>";
        echo "<p><b>Mobile Number:</b> " . $row["MobileNo"] . "</p>";
        echo "<p><b>Seats Booked:</b> " . $row["Seats_booked"] . "</p>";

        // Image for passenger info
        echo "<div class='passenger-img'>";
        echo "<img src='qr.png' alt='Passenger Info Image'>";
        echo "</div>";
        
        // Close passenger information
        echo "</div>";
        echo "</div>"; // This closes the container

        // Close HTML tags
        echo "</body>";
        echo "</html>";
    } else {
        echo "No tickets found for the provided user ID.";
    }

    // Close database connection
    mysqli_close($conn);
} else {
    echo "User ID not found.";
}
?>
