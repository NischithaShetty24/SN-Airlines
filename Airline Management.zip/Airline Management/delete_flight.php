<?php
// Include database connection file
include 'config.php';

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Check if flight ID is set
    if (!isset($_POST['id'])) {
        echo "Flight ID is not set.";
        exit;
    }

    // Retrieve and sanitize flight ID
    $id = $_POST['id'];

    // Prepare the SQL statement
    $sql = "DELETE FROM flights WHERE Id = ?";

    // Bind parameters and execute the query
    $stmt = mysqli_prepare($conn, $sql);
    mysqli_stmt_bind_param($stmt, "s", $id);

    if (mysqli_stmt_execute($stmt)) {
        echo "Flight deleted successfully!";
    } else {
        echo "Error deleting flight: " . mysqli_error($conn);
    }

    // Close statement and database connection
    mysqli_stmt_close($stmt);
    mysqli_close($conn);
} else {
    echo "Invalid request method!";
}
?>
