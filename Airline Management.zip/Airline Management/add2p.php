<?php
// Include database connection file
include 'config.php';

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve and sanitize input data
    $id = $_POST['id'];
    $name = $_POST['name'];
    $source = $_POST['source'];
    $destination = $_POST['destination'];
    $departure = $_POST['departure'];
    $arrival = $_POST['arrival'];
    $fair_economic = $_POST['fair_economic'];
    $fair_business = $_POST['fair_business'];
    $available_seats = $_POST['available_seats'];

    // Your validation and SQL insertion code goes here...
    if (empty($id) || empty($name) || empty($source) || empty($destination) || empty($departure) || empty($arrival) || empty($fair_economic) || empty($fair_business) || empty($available_seats)) {
        echo "Please fill all the fields";
        exit;
    }

    // Prepare the SQL statement
    $sql_check_duplicate = "SELECT * FROM flights WHERE Id=?";
    echo "done";
    $stmt_check_duplicate = mysqli_prepare($conn, $sql_check_duplicate);
    mysqli_stmt_bind_param($stmt_check_duplicate, "s", $id);
    mysqli_stmt_execute($stmt_check_duplicate);
    mysqli_stmt_store_result($stmt_check_duplicate);

    // Check if the flight already exists
    if (mysqli_stmt_num_rows($stmt_check_duplicate) > 0) {
        echo "Flight Not Added. Duplicate flight ID!";
    } else {
        // Insert the flight into the database
        $sql_insert_flight = "INSERT INTO flights(Id, Name, Source, Destination, Departure, Arrival, Fair_Economic, Fair_Business, Available_seats) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)";
        $stmt_insert_flight = mysqli_prepare($conn, $sql_insert_flight);
        mysqli_stmt_bind_param($stmt_insert_flight, "sssssssss", $id, $name, $source, $destination, $departure, $arrival, $fair_economic, $fair_business, $available_seats);

        if (mysqli_stmt_execute($stmt_insert_flight)) {
            echo "Flight Added!!!";

            // Insert source and destination cities if they don't exist
            $sql_insert_source_city = "INSERT IGNORE INTO cities (Name) VALUES(?)";
            echo "done";
            $stmt_insert_source_city = mysqli_prepare($conn, $sql_insert_source_city);
            echo "done";
            mysqli_stmt_bind_param($stmt_insert_source_city, "s", $source);
            mysqli_stmt_execute($stmt_insert_source_city);

            $sql_insert_destination_city = "INSERT IGNORE INTO cities (Name) VALUES(?)";
            $stmt_insert_destination_city = mysqli_prepare($conn, $sql_insert_destination_city);
            mysqli_stmt_bind_param($stmt_insert_destination_city, "s", $destination);
            mysqli_stmt_execute($stmt_insert_destination_city);

            // Redirect the user after a short delay
            header("Refresh:2; url=welcome1.php");
        } else {
            echo "Error: " . mysqli_error($conn);
        }
    }

    // Close database connection
    mysqli_stmt_close($stmt_check_duplicate);
    echo"done";
    mysqli_stmt_close($stmt_insert_flight);
    mysqli_stmt_close($stmt_insert_source_city);
    mysqli_stmt_close($stmt_insert_destination_city);
    mysqli_close($conn);
} else {
    echo "Invalid request method!";
}
?>

   