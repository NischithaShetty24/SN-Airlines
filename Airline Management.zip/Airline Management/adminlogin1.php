<!DOCTYPE html>
<html>
<head>
  <style>
  ul {
    list-style-type: none;
    margin: 0;
    padding: 20px;
    overflow: hidden;
    /*background-color: #5c5c5c;*/
  }

  li {
    float: right;
  }

  li a {
    display: block;
    color: white;
    text-align: center;
    padding: 14px 16px;
    text-decoration: none;
    /*font-weight:bold;*/
  }


  li a:hover:not(.active) {
    background-color: #87cefa;
  }

  .active {
    background-color: #4f94cd;
  }

  body{
    background: url("images/add.jpeg");
    background-size: cover;
    background-repeat: no-repeat;
  }
  .wrapper{
    margin: 0 auto;
    width: 350px; padding: 20px;
    display: block;
    color: black;
    text-align: left;
    padding: 80px 16px;
    text-decoration: none;
    font-size: 25px;
    font-family: sans-serif;
   /*background-image: url("images/admin3.png");
   background-repeat: no-repeat;*/

  }

  input[type=text],[type=number],[type=email],[type=date],[type = password],select{
      width: 100%;
      padding: 12px 20px;
      margin: 8px 0;
      display: inline-block;
      border: 1px solid #ccc;
      border-radius: 4px;
      box-sizing: border-box;
  }

  input[type=submit] {
      width: 100%;
      background-color: #5c5c5c;
      color: white;
      padding: 14px 20px;
      margin: 8px 0;
      border: none;
      border-radius: 4px;
      cursor: pointer;
      font-weight: bold;
      font-size: 15px;
  }

  input[type=submit]:hover {
      background-color: cornflowerblue;
  }

</style>


</head>
<body>

  <ul>
    <li><a href="ab.html">Home</a></li>
    <li style="font-weight: bold;"><a class="active" href="admin.html">Admin</a></li>
    
    <li style="float: left; color:rgb(0, 0, 0); font-weight:bold; font-family: sans-serif;font-size: 43px;">AIRLINE MANAGEMENT SYSTEM</li>
  </ul>
        
  <div class="wrapper">
      
    <h1 style="font-family:sans-serif;">Admin Login</h1><br>
  <form action="admin_login.php" method="post">

    Username: <input type="text" name="username" pattern= "[A-Za-z]+" required></input><br><br>
    Password: <input type="password" name="password" required></input><br><br>

    <input type="submit" value="Login"></input>


  </form>
</div>



</body>
</html>
