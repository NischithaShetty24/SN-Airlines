<!DOCTYPE html>
<html>
<head>
    <title>Modify Flight Details</title>
    <style>
        * {
            margin: 0;
            padding: 0;
            font-family: Century Gothic;
        }

        body {
            background-image: linear-gradient(rgba(0, 0, 0, 0.5), rgba(0, 0, 0, 0.5)), url(plane.jpg);
            height: 100vh;
            background-size: cover;
            background-position: center;
            overflow: auto; /* Enable scrolling */
        }

        ul {
            float: right;
            list-style-type: none;
            margin-top: 25px;
        }

        ul li {
            display: inline-block;
        }

        ul li a {
            text-decoration: none;
            color: #fff;
            padding: 5px 20px;
            border: 1px solid #fff;
            transition: 0.6s ease;
        }

        ul li a:hover {
            background-color: #fff;
            color: #000;
        }

        ul li.active a {
            background-color: #fff;
            color: #000;
        }

        .title {
            text-align: center;
            margin-top: 20px;
            margin-bottom: 30px;
        }

        .title h1 {
            color: #000; /* Black color */
            font-size: 50px;
            font-family: "Comic Sans MS", cursive; /* Change font style */
        }

        .container {
            width: 40%; /* Reduced box size */
            margin: 0 auto;
            border: 1px solid #000; /* Black border */
            padding: 20px;
            color: #000; /* Black text color */
            text-decoration: none;
            transition: 0.6s ease;
            font-size: 20px;
            background-color: rgba(255, 255, 255, 0.5); /* Transparent white background */
        }

        input[type=submit] {
            border: none;
            padding: 10px 20px; /* Reduced padding */
            text-decoration: none;
            transition: 0.6s ease;
            background-color: #000; /* Black background */
            color: #fff; /* White color */
            font-size: 18px; /* Reduced font size */
            cursor: pointer;
            border-radius: 4px;
        }

        input[type=submit]:hover {
            background-color: #555; /* Darker background on hover */
        }

        input[type=text],
        input[type=date],
        input[type=number] {
            width: calc(100% - 24px); /* Adjust width to fit in the box */
            padding: 10px;
            margin: 8px 0;
            display: block;
            border: 1px solid #ccc;
            border-radius: 4px;
            box-sizing: border-box;
            font-size: 18px; /* Larger font size */
        }

        label {
            margin-bottom: 5px;
            display: block;
        }

    </style>
</head>
<body>
    <div class="main">
        <ul>
            <li class="active"><a href="#">Modify Flights</a></li>
            <li><a href="ab.html">Home</a></li>
        </ul>
    </div>
    <div class="title">
        <h1>Modify Flight</h1>
    </div>
    <div class="container">
        <?php
            $flight_id= $_POST['id'];
            include 'config.php';
            $test = "SELECT * FROM flights WHERE Id = $flight_id";
            $result = mysqli_query($conn,$test);
            $row = mysqli_fetch_array($result,MYSQLI_ASSOC);

            $count = mysqli_num_rows($result);

            if ($count == 0) {
                $error = "Flight ID NOT FOUND!!!<br><br>";
                echo $error;
                header("Refresh:2; url=updateflight.html");
            } else {
                $sql= "SELECT Name,Source,Destination,Departure,Arrival,Fair_Economic,Fair_Business FROM flights WHERE Id = $flight_id";
                $res=mysqli_query($conn,$sql);
                $row = mysqli_fetch_assoc($res);
                mysqli_close($conn);
            }
        ?>

        <form action="m3.php" method="post">
            <input name="id" type="hidden" value="<?php echo $flight_id; ?>">

            <label>Flight Name:</label>
            <input type="text" name="name" value="<?php echo $row['Name']; ?>" required><br><br>
            <label>Source:</label>
            <input type="text" name="source" value="<?php echo $row['Source']; ?>" required><br><br>
            <label>Destination:</label>
            <input type="text" name="destination" value="<?php echo $row['Destination']; ?>" required><br><br>
            <label>Departure:</label>
            <input type="date" name="departure" value="<?php echo $row['Departure']; ?>" required><br><br>
            <label>Arrival:</label>
            <input type="date" name="arrival" value="<?php echo $row['Arrival']; ?>" required><br><br>
            <label>Economic Fair:</label>
            <input type="number" name="Fair_Economic" value="<?php echo $row['Fair_Economic']; ?>" required><br><br>
            <label>Business Fair:</label>
            <input type="number" name="Fair_Business" value="<?php echo $row['Fair_Business']; ?>" required><br><br>
            <input type="submit" value="Update Flight">
        </form>
    </div>
</body>
</html>
