<?php
session_start();

// Check if the form is submitted
if ($_SERVER["REQUEST_METHOD"] == "POST") {
    // Retrieve form data
    $username = $_POST['username'];
    $password = $_POST['password'];

    // Check credentials against database (You'll need to implement this part)
    // Example:
    $db_username = 'Nis'; // Replace with actual admin username
    $db_password = '2003'; // Replace with actual admin password

    if ($username === $db_username && $password === $db_password) {
        // Authentication successful
        $_SESSION['admin'] = true; // Set admin session variable
        header("Location: adminoption.html"); // Redirect to admin dashboard
        exit();
    } else {
        // Authentication failed
        echo "Invalid username or password!";
    }
}
?>
